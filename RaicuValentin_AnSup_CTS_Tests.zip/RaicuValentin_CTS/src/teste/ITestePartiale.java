package teste;

public class ITestePartiale {

}
