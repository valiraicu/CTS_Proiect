package teste;

import static org.junit.Assert.*;
import interfaces.ISuporter;

import org.junit.Test;
import org.junit.experimental.categories.Category;



import patterns.CareTaker;
import patterns.FotbalistBuilder;
import patterns.Memento;
import patterns.SuporterFactory;

import clase.Antrenor;
import clase.Capitan;
import clase.Fotbalist;
import clase.SuporterPortughez;
import exceptii.ExceptieCNPIncorect;
import exceptii.ExceptieNiciUnCampionatCastigat;

public class TestCase2 {

	@Test
	public void TestRezultateCorecteAcordareVenituri() throws ExceptieNiciUnCampionatCastigat, ExceptieCNPIncorect {
		
		Antrenor Iordanescu = new Antrenor("1642112033371",3,1.5,4,"Romania");
		assertEquals(Iordanescu.Venituri(), 18,0);
		
	}
	
	@Test(expected = ExceptieNiciUnCampionatCastigat.class)
	public void TestAcordareVenituriFaraMerite() throws ExceptieNiciUnCampionatCastigat, ExceptieCNPIncorect {
		
		Antrenor Iordanescu = new Antrenor("1642112033371",3,1.5,0,"Romania");
		assertEquals(Iordanescu.Venituri(), 18,0);
		
	}
	
	@Category( {ITestePartiale.class} )
	@Test
	public void TestRezultateCorecteAcordareVenituriCrossCheck() throws ExceptieNiciUnCampionatCastigat, ExceptieCNPIncorect {
		
		Antrenor Iordanescu = new Antrenor("1642112033371",3,1.5,4,"Romania");
		double cross = Iordanescu.getComision()*Iordanescu.getJucatoriDeAntrenat()*Iordanescu.getCampionateCastigate();
		assertEquals(cross, Iordanescu.Venituri(),0);
		
	}
	
	@Test(expected = ExceptieCNPIncorect.class)
	public void TestCorectitudineCNP() throws ExceptieNiciUnCampionatCastigat, ExceptieCNPIncorect {
		
		Antrenor Iordanescu = new Antrenor("164213371",3,1.5,0,"Romania");
				
	}

	@Test(expected = ExceptieCNPIncorect.class)
	public void TestCorectitudineCNPNull() throws ExceptieNiciUnCampionatCastigat, ExceptieCNPIncorect {
		
		Antrenor Iordanescu = new Antrenor("",3,1.5,0,"Romania");
				
	}
	
	@Test
	public void TestConstructor() throws ExceptieNiciUnCampionatCastigat, ExceptieCNPIncorect {
		
		Antrenor Iordanescu = new Antrenor("1642112033371",3,1.5,4,"Romania");
		assertEquals("Romania",Iordanescu.getEchipa());
		
	}
	
	@Category( {ITestePartiale.class} )
	@Test
	public void TestRandamentAntrenori() throws ExceptieCNPIncorect  {
		
		Antrenor Iordanescu = new Antrenor("1642112033371",3,1.5,4,"Romania");
		Antrenor Dorel = new Antrenor("1234567891234",3,1.5,4,"Belgia");
		Iordanescu.setVarsta(50);
		Dorel.setVarsta(30);
		assertEquals(Iordanescu,Dorel.AntrenorMaiBun(Dorel, Iordanescu));
		
	}
	
	@Test
	public void TestCreareFotbalist()
	{
		
		FotbalistBuilder builder = new FotbalistBuilder();
		Fotbalist f1 = builder.set_numar(10).set_nume("Klose").set_salariu(112).build();
		Fotbalist f2 = new Fotbalist(10,"Klose",112);
		assertNotSame(f1, f2);
		
		
	}
	
	
	@Test
	
	public void TestRandamentCapitan()
	{
		Capitan c1= new Capitan(33,11);
		Capitan c2 = new Capitan(4,18);
		
		assertEquals(3, c1.ScorCaptitan(),0);
				
	}
	
	@Test

	public void TestRandamentIntreCapitani()
	{
		Capitan c1= new Capitan(33,11);
		Capitan c2 = new Capitan(4,18);
		
		assertEquals(c1, c2.RandamentCapitani(c1, c2));
				
	}
	
	@Test
	
	public void TestareMemento(){
		
		Fotbalist juc1 = new Fotbalist(10, "Rat", 2);
		
		CareTaker caretaker = new CareTaker();
		Memento memento = new Memento(juc1);
		caretaker.addMemento(memento);
				
		assertEquals("Rat", caretaker.getMemento(0).getfotbalist().getNume());
	}
	
	
	
	
	
	
}
