package teste;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.categories.Category;

import clase.Fotbalist;
import clase.Meci;
import exceptii.ExceptieInsuficientiSuporteri;
import exceptii.ExceptieMarireSalariu;
import exceptii.ExceptieSalariuNull;

public class TestCase1 {

	@Test
	public void TestMarireSalariu() throws ExceptieMarireSalariu {
		
		Fotbalist f1 = new Fotbalist(1,"Dorel",200);
		f1.mariresalariu();
		assertEquals(400, f1.getSalariu(),0);
		
	}
	
	@Category( {ITestePartiale.class} )
	@Test(expected = ExceptieMarireSalariu.class)
	public void InadecvatPentruMarire() throws ExceptieMarireSalariu {
		
		Fotbalist f1 = new Fotbalist(1,"Dorel",750);
		f1.mariresalariu();
		
		
	}
	

	@Test(expected = ExceptieSalariuNull.class)
	public void SalariulNuPoateFiNull() throws  ExceptieSalariuNull {
		
		Fotbalist f1 = new Fotbalist(1,"Dorel",750);
		f1.setSalariu(0);
		
		
	}
	
	@Category( {ITestePartiale.class} )
	@Test(expected = ExceptieInsuficientiSuporteri.class)
	public void TestPentruMeciFaraSuporteri() throws   ExceptieInsuficientiSuporteri {
		
		Meci meci = new Meci("echipa1","echipa2");
		meci.incepe();
		
		
	}
	
	
}
